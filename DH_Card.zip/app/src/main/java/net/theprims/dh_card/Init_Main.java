package net.theprims.dh_card;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class Init_Main extends AppCompatActivity implements View.OnClickListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.init_main);

        Button bt4x4 = (Button)findViewById(R.id.BT4x4);
        Button bt5x5 = (Button)findViewById(R.id.BT5x5);
        Button bt6x6 = (Button)findViewById(R.id.BT6x6);

        bt4x4.setOnClickListener(this);
        bt5x5.setOnClickListener(this);
        bt6x6.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.BT4x4 :
                Intent intent=new Intent(Init_Main.this, GameActivity.class);
                intent.putExtra("Type", "4");
                startActivity(intent);
                break;

            case R.id.BT5x5 :

                break;

            case R.id.BT6x6 :

                break;

        }
    }
}
