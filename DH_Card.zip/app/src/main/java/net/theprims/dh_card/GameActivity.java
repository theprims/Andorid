package net.theprims.dh_card;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridLayout;
import android.widget.ImageView;

public class GameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_4x4);

        Intent intent=new Intent(this.getIntent());
        String Type = intent.getStringExtra("Type");

        GridLayout Grid = (GridLayout)findViewById(R.id.Grid);
        Grid.setColumnCount(4);
        Grid.setRowCount(4);

        String packName = this.getPackageName();
        int BackImag = getResources().getIdentifier("@R.drawable.QuestionMark","drawable",packName);
        ImageView[] image = new ImageView[16];

        int imageCount = 0;
        for(int i = 0; i < 4; i++){
            for(int j = 0; j < 4; i++){
                image[imageCount] = new ImageView(this);
                image[imageCount].setImageResource(BackImag);
                Grid.addView(image[imageCount]);
            }
        }

    }
}
